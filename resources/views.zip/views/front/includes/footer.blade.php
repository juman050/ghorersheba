	<footer>        
	    <div class="footer-section-copyright text-center">
	        <p>
	            © <?php echo date('Y');?> ghorersheba.com. All Rights Reserved.
	        </p>
	    </div>
	</footer>
	<!-- Return to Top -->
	<a href="javascript:" id="return-to-top"><i class="fa fa-angle-up"></i></a>
</div>