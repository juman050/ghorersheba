<div class='title m-b-md'>
{{ strtoupper($message)}} only page!
</div>