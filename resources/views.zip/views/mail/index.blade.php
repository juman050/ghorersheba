<p>Hello <b>{{$firstname}}</b></p>
<p>{!! $msg !!}</p>
