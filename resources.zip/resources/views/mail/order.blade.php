<p>Hello <b>{{$firstname}}</b></p>
<p>Thanks for your order.</p>
<p>{!! $msg !!}</p>