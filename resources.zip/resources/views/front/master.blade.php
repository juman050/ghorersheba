<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Ghorer-Sheba | @yield('title')</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="{{ asset('public/front/css/bootstrap.min.css') }}">
        <link rel="stylesheet" href="{{ asset('public/front/css/font-awesome.min.css') }}">
        <link rel="stylesheet" href="{{ asset('public/front/css/bootstrap-select.min.css') }}">
        <link rel="stylesheet" href="{{ asset('public/front/css/style.css') }}">
        
        
    </head>
    <body>
        <!-- header -->
        @include('front.includes.header')
        
        <!-- maincontent -->
        @yield('mainContent')
       
        <!-- footer -->
        @include('front.includes.footer')

        <!-- jQuery v3.1.1 -->
        <script src="{{ asset('public/front/js/jquery.min.js') }}"></script>
        <!-- Bootstrap v3.3.7 -->
        <script src="{{ asset('public/front/js/bootstrap.min.js') }}"></script>
        <!--=== validate js ===-->
        <script type="text/javascript" src="{{ asset('public/front/js/jquery.validate.min.js') }}"></script>
        <!--=== custom js ===-->
        <script src="{{ asset('public/front/js/bootstrap-select.min.js') }}"></script>
        <!--=== custom js ===-->
        <script src="{{ asset('public/front/js/custom.js') }}"></script>
        @stack('scripts');
        <!--=== service js ===-->
        <script type="text/javascript">
          // ===== Scroll to Top ==== 
          $(window).scroll(function() {
              if ($(this).scrollTop() >= 50) {        // If page is scrolled more than 50px
                  $('#return-to-top').fadeIn(200);    // Fade in the arrow
              } else {
                  $('#return-to-top').fadeOut(200);   // Else fade out the arrow
              }
          });
          $('#return-to-top').click(function() {      // When arrow is clicked
              $('body,html').animate({
                  scrollTop : 0                       // Scroll to top of body
              }, 500);
          });
   
      </script>
        
      <script>
        $(document).ready(function() {
          $('.selectpicker').selectpicker();          
        });
      </script>
    </body>
</html>
